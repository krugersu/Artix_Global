#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->KeyComb->setText("Key CombDisplay");
    ui->KeyCode->setText("Keycode");
    ui->KeyNative->setText("Keycode Native");

    ui->KeyCombLine->setReadOnly(true);
    ui->KeyCodeLine->setReadOnly(true);
    ui->KeyNativeLine->setReadOnly(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    QString keyComb, keyCode, keyNative;
    keyCode = QString::number(this->toKeycode(event));
    keyNative = QString::number(event->nativeVirtualKey());

    if(onlyModiferKey(event)) {
        keyComb = QKeySequence(event->modifiers()).toString();
    } else {
        keyComb = QKeySequence(event->modifiers() | event->key()).toString();
    }

    ui->KeyCombLine->setText(keyComb);
    ui->KeyCodeLine->setText(keyCode);
    ui->KeyNativeLine->setText(keyNative);
}

int MainWindow::toKeycode(QKeyEvent *e) {

    int keycode = e->nativeVirtualKey();

    if (e->key() == Qt::Key_Enter || e->key() == Qt::Key_Return) {
        keycode = 13;
    }
    else if (onlyModiferKey(e) || e->nativeVirtualKey() == 0xfe08) {    // Change keyboard layout (ISO_Next_Group)
        keycode = 0;
    }
    else if (e->key() == Qt::Key_Escape) {
        keycode = 27;
    }
    else if (e->key() == Qt::Key_Down) {
        keycode = 258;
    }
    else if (e->key() == Qt::Key_Up) {
        keycode = 259;
    }
    else if (e->key() == Qt::Key_Left) {
        keycode = 260;
    }
    else if (e->key() == Qt::Key_Right) {
        keycode = 261;
    }
    else if (e->key() == Qt::Key_End) {
        keycode = 360;
    }
    else if (e->key() == Qt::Key_Home) {
        keycode = 262;
    }
    else if (e->key() == Qt::Key_PageDown) {
        keycode = 338;
    }
    else if (e->key() == Qt::Key_PageUp) {
        keycode = 339;
    }
    else if (e->key() == Qt::Key_Delete) {
        keycode = 330;
    }
    else if (e->key() == Qt::Key_Insert) {
        keycode = 331;
    }
    else if (e->key() == Qt::Key_Backspace) {
        keycode = 8;
    }
    else if (e->key() == Qt::Key_Tab) {
        keycode = 9;
    }
    else if (e->modifiers() & Qt::ShiftModifier && e->modifiers() &  Qt::ControlModifier ) {
        if(this->isFunctionKey(e->key())) {
            keycode = 301 + e->key() - Qt::Key_F1;
        }
        else {
            keycode = e->nativeVirtualKey();
            e->setModifiers(Qt::ShiftModifier);
        }
    }
    else if (e->modifiers() & Qt::ControlModifier) {
        if (e->nativeVirtualKey() >= 97 && e->nativeVirtualKey() <= 122) {
            keycode = 1200 + e->nativeVirtualKey() - 97;
        }
        else if (this->isFunctionKey(e->key())) {
            keycode = 289 + e->key() - Qt::Key_F1;
        }
    }
    else if (e->modifiers() & Qt::ShiftModifier) {
        if (this->isFunctionKey(e->key())) {
            keycode = 277 + e->key() - Qt::Key_F1;
        }
        else if (e->nativeVirtualKey() >= 65 && e->nativeVirtualKey() <= 90) {
            keycode = e->nativeVirtualKey();
        }
    }
    else if (e->modifiers() & Qt::AltModifier) {
        if (e->nativeVirtualKey() >= 97 && e->nativeVirtualKey() <= 122) {
            keycode = 1065 + e->nativeVirtualKey() - 97;
        }
        else if (this->isFunctionKey(e->key())) {
            keycode = 313 + e->key() - Qt::Key_F1;
        }
        else {
            keycode = 1000 + e->nativeVirtualKey();
        }
    }
    else if (this->isFunctionKey(e->key())) {
        keycode = 265 + e->key() - Qt::Key_F1;
    }

    return keycode;
}

bool MainWindow::isFunctionKey(int key)
{
    if (key >= Qt::Key_F1 && key <= Qt::Key_F12)
        return true;
    return false;
}

bool MainWindow::onlyModiferKey(QKeyEvent *e)
{
    QList<Qt::Key> modKeys = {Qt::Key_Shift, Qt::Key_Alt, Qt::Key_AltGr, Qt::Key_Control, Qt::Key_Meta};
    if(modKeys.contains(e->key()))
        return true;
    return false;
}
